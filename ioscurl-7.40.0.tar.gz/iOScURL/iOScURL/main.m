//
//  main.m
//  iOScURL
//
//  Created by Nick Zitzmann on 11/3/12.
//  Copyright (c) 2012 Nick Zitzmann. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ICAppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([ICAppDelegate class]));
	}
}
